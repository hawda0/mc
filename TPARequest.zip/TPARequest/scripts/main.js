import { world, system, CommandPermissionLevel, CustomCommandStatus } from "@minecraft/server";
import { ActionFormData, MessageFormData } from "@minecraft/server-ui";

const BLOCKED_KEY = "tpa:blocked";
const BLOCK_ALL_KEY = "tpa:blockAll";
const REQUEST_TIMEOUT_TICKS = 600;
const RETRY_DELAY_TICKS = 20;

const pendingRequests = new Map();
const activeSenders = new Map();

function getPlayerById(id) {
  return world.getAllPlayers().find((p) => p.id === id);
}

function getBlockedList(player) {
  const raw = player.getDynamicProperty(BLOCKED_KEY);
  if (typeof raw !== "string") return [];
  try {
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

function setBlockedList(player, list) {
  player.setDynamicProperty(BLOCKED_KEY, JSON.stringify(list));
}

function isBlockAllEnabled(player) {
  return player.getDynamicProperty(BLOCK_ALL_KEY) === true;
}

function setBlockAllEnabled(player, value) {
  player.setDynamicProperty(BLOCK_ALL_KEY, value);
}

function isBlocked(target, requesterId) {
  if (isBlockAllEnabled(target)) return true;
  return getBlockedList(target).some((b) => b.id === requesterId);
}

function clearPending(targetId, requesterId) {
  const pending = pendingRequests.get(targetId);
  if (pending) {
    system.clearRun(pending.timeoutHandle);
    pendingRequests.delete(targetId);
  }
  if (requesterId) activeSenders.delete(requesterId);
}

function showMainMenu(player) {
  const requestsEnabled = !isBlockAllEnabled(player);
  const form = new ActionFormData()
    .title("TPA Menu")
    .body("What would you like to do?")
    .button("Send Teleport Request")
    .button("Blocked Players")
    .button(`Teleport Requests: ${requestsEnabled ? "§aOn" : "§cOff"}`);

  form.show(player).then((response) => {
    if (response.canceled) return;
    if (response.selection === 0) showSendRequestMenu(player);
    else if (response.selection === 1) showBlockedMenu(player);
    else if (response.selection === 2) {
      setBlockAllEnabled(player, requestsEnabled);
      player.sendMessage(
        requestsEnabled
          ? "§cTeleport requests turned off. No one can send you a request now."
          : "§aTeleport requests turned on. Players you blocked individually are still blocked."
      );
      showMainMenu(player);
    }
  });
}

function showSendRequestMenu(player) {
  const others = world.getAllPlayers().filter((p) => p.id !== player.id);

  if (others.length === 0) {
    new MessageFormData()
      .title("Send Teleport Request")
      .body("There are no other players online.")
      .button1("OK")
      .show(player);
    return;
  }

  const form = new ActionFormData().title("Select Player").body("Who do you want to send a teleport request to?");
  others.forEach((p) => form.button(p.name));

  form.show(player).then((response) => {
    if (response.canceled) return;
    sendTpaRequest(player, others[response.selection]);
  });
}

function sendTpaRequest(requester, target) {
  if (isBlocked(target, requester.id)) {
    requester.sendMessage(`§c${target.name} is not accepting teleport requests.`);
    return;
  }

  if (activeSenders.has(requester.id)) {
    requester.sendMessage("§eYou already have a pending teleport request. Wait for a response or for it to expire.");
    return;
  }

  if (pendingRequests.has(target.id)) {
    requester.sendMessage(`§e${target.name} already has a pending request, try again in a moment.`);
    return;
  }

  const timeoutHandle = system.runTimeout(() => {
    const pending = pendingRequests.get(target.id);
    if (!pending || pending.requesterId !== requester.id) return;
    clearPending(target.id, requester.id);
    const requesterNow = getPlayerById(requester.id);
    if (requesterNow) requesterNow.sendMessage(`§e${target.name} did not respond in time.`);
  }, REQUEST_TIMEOUT_TICKS);

  pendingRequests.set(target.id, {
    requesterId: requester.id,
    requesterName: requester.name,
    timeoutHandle,
  });
  activeSenders.set(requester.id, target.id);

  requester.sendMessage(`§aTeleport request sent to ${target.name}.`);
  target.sendMessage(`§e${requester.name} wants to teleport to you. Opening the request menu...`);
  attemptShowRequestForm(target, requester.id, requester.name);
}

function attemptShowRequestForm(target, requesterId, requesterName) {
  const pending = pendingRequests.get(target.id);
  if (!pending || pending.requesterId !== requesterId) return;

  const form = new MessageFormData()
    .title("Teleport Request")
    .body(`§a${requesterName}§r wants to teleport to you.`)
    .button1("§aAccept")
    .button2("§cDecline");

  form.show(target).then((response) => {
    const stillPending = pendingRequests.get(target.id);
    if (!stillPending || stillPending.requesterId !== requesterId) return;

    if (response.canceled) {
      system.runTimeout(() => attemptShowRequestForm(target, requesterId, requesterName), RETRY_DELAY_TICKS);
      return;
    }

    clearPending(target.id, requesterId);
    if (response.selection === 0) acceptRequest(target, requesterId, requesterName);
    else declineRequest(target, requesterId, requesterName);
  });
}

function acceptRequest(target, requesterId, requesterName) {
  const requester = getPlayerById(requesterId);
  if (!requester) {
    target.sendMessage(`§c${requesterName} is no longer online.`);
    return;
  }

  requester.teleport(target.location, { dimension: target.dimension });
  requester.sendMessage(`§aYou were teleported to ${target.name}.`);
  target.sendMessage(`§aYou accepted ${requesterName}'s teleport request.`);
}

function declineRequest(target, requesterId, requesterName) {
  const requester = getPlayerById(requesterId);
  if (requester) requester.sendMessage(`§c${target.name} declined your teleport request.`);
  target.sendMessage(`§eYou declined ${requesterName}'s teleport request.`);
}

function showBlockedMenu(player) {
  const blockedList = getBlockedList(player);
  const form = new ActionFormData()
    .title("Blocked Players")
    .body("Tap a player to unblock them, or use 'Add Player' to block someone new.");

  blockedList.forEach((b) => form.button(`${b.name} §c(remove)`));
  form.button("§a+ Add Player");

  form.show(player).then((response) => {
    if (response.canceled) return;
    if (response.selection === blockedList.length) {
      showAddBlockedMenu(player);
      return;
    }
    const removed = blockedList[response.selection];
    const updated = blockedList.filter((b) => b.id !== removed.id);
    setBlockedList(player, updated);
    player.sendMessage(`§aUnblocked ${removed.name}.`);
    showBlockedMenu(player);
  });
}

function showAddBlockedMenu(player) {
  const blockedList = getBlockedList(player);
  const candidates = world
    .getAllPlayers()
    .filter((p) => p.id !== player.id && !blockedList.some((b) => b.id === p.id));

  if (candidates.length === 0) {
    new MessageFormData()
      .title("Add Player")
      .body("There are no online players available to block.")
      .button1("OK")
      .show(player)
      .then(() => showBlockedMenu(player));
    return;
  }

  const form = new ActionFormData().title("Add Player").body("Who do you want to block?");
  candidates.forEach((p) => form.button(p.name));

  form.show(player).then((response) => {
    if (response.canceled) {
      showBlockedMenu(player);
      return;
    }
    const target = candidates[response.selection];
    const updated = [...blockedList, { id: target.id, name: target.name }];
    setBlockedList(player, updated);
    player.sendMessage(`§aBlocked ${target.name}.`);
    showBlockedMenu(player);
  });
}

world.afterEvents.playerLeave.subscribe((ev) => {
  clearPending(ev.playerId, undefined);
  activeSenders.delete(ev.playerId);
  for (const [targetId, pending] of pendingRequests) {
    if (pending.requesterId === ev.playerId) clearPending(targetId, ev.playerId);
  }
});

system.beforeEvents.startup.subscribe((ev) => {
  ev.customCommandRegistry.registerCommand(
    {
      name: "tpasystem:tpa",
      description: "Open the teleport request menu.",
      permissionLevel: CommandPermissionLevel.Any,
      cheatsRequired: false,
    },
    (origin) => {
      const player = origin.sourceEntity;
      if (!player) {
        return { status: CustomCommandStatus.Failure, message: "This command can only be used by a player." };
      }
      system.run(() => showMainMenu(player));
      return { status: CustomCommandStatus.Success, message: "" };
    }
  );
});
