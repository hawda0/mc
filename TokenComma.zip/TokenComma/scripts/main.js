import {
  world,
  system,
  CommandPermissionLevel,
  CustomCommandStatus,
} from "@minecraft/server";

const PACK_ID = "server";
const TOKEN_OBJECTIVE_ID = ":token:";
const NIGHT_VISION_SECONDS = 9999;
const NIGHT_VISION_TICKS = NIGHT_VISION_SECONDS * 20;
const DIAMOND_ID = "minecraft:diamond";
const NETHERITE_INGOT_ID = "minecraft:netherite_ingot";
const SHOP_POS = { x: 100, y: 100, z: 100 };
const COMMAND_SOUND = "random.levelup";

function getPlayerFromOrigin(origin) {
  const entity = origin?.sourceEntity;
  return entity?.typeId === "minecraft:player" ? entity : undefined;
}

function ensureTokenObjective() {
  const existing = world.scoreboard.getObjective(TOKEN_OBJECTIVE_ID);
  if (existing) return existing;

  try {
    return world.scoreboard.addObjective(TOKEN_OBJECTIVE_ID, TOKEN_OBJECTIVE_ID);
  } catch {
    return world.scoreboard.getObjective(TOKEN_OBJECTIVE_ID);
  }
}

function playCommandSound(player) {
  try {
    player.playSound(COMMAND_SOUND, { volume: 1, pitch: 1 });
  } catch {
    // Non-critical.
  }
}

function getSelectedStack(player) {
  const inventory = player.getComponent("inventory")?.container;
  if (!inventory) return undefined;
  return inventory.getSlot(player.selectedSlotIndex)?.getItem();
}

function setSelectedSlotEmpty(player) {
  const inventory = player.getComponent("inventory")?.container;
  if (!inventory) return false;
  const slot = inventory.getSlot(player.selectedSlotIndex);
  if (!slot) return false;
  slot.setItem(undefined);
  return true;
}

function tell(player, message) {
  player.sendMessage(message);
}

function giveNightVision(player) {
  player.addEffect("night_vision", NIGHT_VISION_TICKS, {
    amplifier: 0,
    showParticles: false,
  });
  tell(player, `§aNight vision granted for §e${NIGHT_VISION_SECONDS}§a seconds.`);
  playCommandSound(player);
  return true;
}

function sellHeldItem(player) {
  const stack = getSelectedStack(player);
  if (!stack) {
    tell(player, "§cHold diamonds or netherite ingots in your selected hotbar slot.");
    return false;
  }

  const amount = stack.amount ?? 0;
  if (amount <= 0) {
    tell(player, "§cThat stack cannot be sold.");
    return false;
  }

  let valuePerItem = 0;
  let soldName = "";
  if (stack.typeId === DIAMOND_ID) {
    valuePerItem = 5;
    soldName = "diamond";
  } else if (stack.typeId === NETHERITE_INGOT_ID) {
    valuePerItem = 50;
    soldName = "netherite ingot";
  } else {
    tell(player, "§cOnly diamonds and netherite ingots can be sold.");
    return false;
  }

  const objective = ensureTokenObjective();
  if (!objective) {
    tell(player, "§cToken scoreboard objective could not be created.");
    return false;
  }

  const tokens = amount * valuePerItem;
  if (!setSelectedSlotEmpty(player)) {
    tell(player, "§cYour selected slot is unavailable.");
    return false;
  }

  objective.addScore(player, tokens);
  tell(player, `§aSold ${amount} ${soldName}${amount === 1 ? "" : "s"} for §e${tokens}§a token${tokens === 1 ? "" : "s"}.`);
  playCommandSound(player);
  return true;
}

function teleportPlayer(player, location, message) {
  try {
    player.teleport(location, {
      dimension: player.dimension,
      checkForBlocks: false,
      keepVelocity: false,
    });
    tell(player, message);
    playCommandSound(player);
    return true;
  } catch (error) {
    tell(player, "§cTeleport failed.");
    console.warn(`[${PACK_ID}] Teleport failed for ${player.name}: ${error?.stack ?? error}`);
    return false;
  }
}

function handleSlashCommand(player, rawMessage) {
  const input = rawMessage.trim();
  if (!input.startsWith("/")) return false;

  const parts = input.slice(1).trim().split(/\s+/);
  const command = (parts.shift() ?? "").toLowerCase();
  const arg = parts.join(" ");

  switch (command) {
    case "nv":
      return giveNightVision(player);
    case "sell":
      return sellHeldItem(player);
    case "shop":
      return teleportPlayer(player, SHOP_POS, "§aTeleported to the shop.");
    default:
      return false;
  }
}

function registerNamespacedCommands(init) {
  const registry = init.customCommandRegistry;

  registry.registerCommand(
    {
      name: `${PACK_ID}:nv`,
      description: "Grant night vision for 9999 seconds.",
      permissionLevel: CommandPermissionLevel.Any,
      cheatsRequired: false,
    },
    (origin) => {
      const player = getPlayerFromOrigin(origin);
      if (!player) return { status: CustomCommandStatus.Failure, message: "Only a player can use this command." };
      system.run(() => giveNightVision(player));
      return { status: CustomCommandStatus.Success, message: "Night vision queued." };
    }
  );

  registry.registerCommand(
    {
      name: `${PACK_ID}:sell`,
      description: "Sell diamonds or netherite ingots from your hand for tokens.",
      permissionLevel: CommandPermissionLevel.Any,
      cheatsRequired: false,
    },
    (origin) => {
      const player = getPlayerFromOrigin(origin);
      if (!player) return { status: CustomCommandStatus.Failure, message: "Only a player can use this command." };
      system.run(() => sellHeldItem(player));
      return { status: CustomCommandStatus.Success, message: "Sell queued." };
    }
  );

  registry.registerCommand(
    {
      name: `${PACK_ID}:shop`,
      description: "Teleport to the shop.",
      permissionLevel: CommandPermissionLevel.Any,
      cheatsRequired: false,
    },
    (origin) => {
      const player = getPlayerFromOrigin(origin);
      if (!player) return { status: CustomCommandStatus.Failure, message: "Only a player can use this command." };
      system.run(() => teleportPlayer(player, SHOP_POS, "§aTeleported to the shop."));
      return { status: CustomCommandStatus.Success, message: "Shop queued." };
    }
  );

}

system.beforeEvents.startup.subscribe((init) => {
  registerNamespacedCommands(init);

  system.run(() => {
    try {
      ensureTokenObjective();
    } catch (error) {
      console.warn(`[${PACK_ID}] Unable to initialize scoreboard objective: ${error?.stack ?? error}`);
    }
  });
});

world.beforeEvents.chatSend.subscribe((event) => {
  const handled = handleSlashCommand(event.sender, event.message);
  if (!handled) return;
  event.cancel = true;
});
