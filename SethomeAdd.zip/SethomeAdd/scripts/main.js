import { world, system, ItemStack, Player } from '@minecraft/server';
import { ActionFormData, ModalFormData, MessageFormData } from '@minecraft/server-ui';

// Home management system
class HomeManager {
    constructor() {
        this.homes = new Map();
        this.homeCountLimits = new Map();
        this.loadData();
    }

    loadData() {
        try {
            const homeData = world.getDynamicProperty('sethome_homes');
            if (homeData) {
                this.homes = new Map(JSON.parse(homeData));
            }
            
            const limitData = world.getDynamicProperty('sethome_limits');
            if (limitData) {
                this.homeCountLimits = new Map(JSON.parse(limitData));
            }
        } catch (error) {
            console.warn('Error loading home data:', error);
        }
    }

    saveData() {
        try {
            world.setDynamicProperty('sethome_homes', JSON.stringify(Array.from(this.homes.entries())));
            world.setDynamicProperty('sethome_limits', JSON.stringify(Array.from(this.homeCountLimits.entries())));
        } catch (error) {
            console.warn('Error saving home data:', error);
        }
    }

    getPlayerHomes(playerId) {
        return this.homes.get(playerId) || [];
    }

    getPlayerHomeLimit(player) {
        // Check for homes tags (homes1, homes2, homes3, etc.)
        const tags = player.getTags();
        for (const tag of tags) {
            if (tag.startsWith('homes') && tag.length > 5) {
                const number = parseInt(tag.substring(5));
                if (!isNaN(number) && number > 0) {
                    return number;
                }
            }
        }
        return 1; // Default limit
    }

// Remove the showListHomesMenu function and setPlayerHomeLimit function
    setPlayerHomeLimit(playerId, limit) {
        this.homeCountLimits.set(playerId, limit);
        this.saveData();
    }

    addHome(player, homeName, location) {
        if (!this.homes.has(player.id)) {
            this.homes.set(player.id, []);
        }
        
        const playerHomes = this.homes.get(player.id);
        const limit = this.getPlayerHomeLimit(player);
        
        if (playerHomes.length >= limit) {
            return false;
        }
        
        // Remove existing home with same name
        const existingIndex = playerHomes.findIndex(home => home.name === homeName);
        if (existingIndex !== -1) {
            playerHomes.splice(existingIndex, 1);
        }
        
        playerHomes.push({
            name: homeName,
            x: location.x,
            y: location.y,
            z: location.z,
            dimension: location.dimension
        });
        
        this.saveData();
        return true;
    }

    removeHome(playerId, homeName) {
        const playerHomes = this.homes.get(playerId);
        if (playerHomes) {
            const index = playerHomes.findIndex(home => home.name === homeName);
            if (index !== -1) {
                playerHomes.splice(index, 1);
                this.saveData();
                return true;
            }
        }
        return false;
    }

    getHome(playerId, homeName) {
        const playerHomes = this.homes.get(playerId);
        if (playerHomes) {
            return playerHomes.find(home => home.name === homeName);
        }
        return null;
    }
}

const homeManager = new HomeManager();

// Give compass on spawn
world.afterEvents.playerSpawn.subscribe((event) => {
    const { player, initialSpawn } = event;
    
    if (initialSpawn) {
        system.run(() => {
            const compass = new ItemStack('minecraft:compass', 1);
            compass.nameTag = '§6Sethome';
            compass.setLore(['§7Right-click to open home menu', '§7Manage your homes with ease!']);
            
            player.getComponent('minecraft:inventory').container.addItem(compass);
            
        });
    }
});

// Handle compass usage
world.afterEvents.itemUse.subscribe((event) => {
    const { source: player, itemStack } = event;
    
    if (itemStack.typeId === 'minecraft:compass' && 
        itemStack.nameTag === '§6Sethome') {
        system.run(() => {
            showMainMenu(player);
        });
    }
});

// Main menu GUI
async function showMainMenu(player) {
    const homes = homeManager.getPlayerHomes(player.id);
    const limit = homeManager.getPlayerHomeLimit(player);
    
    const form = new ActionFormData();
    form.title('§6§lHOME MANAGER');
    form.body(`§b§lHomes: §f${homes.length}§7/§f${limit}`);
    
    form.button('§a§l➕ SET HOME\n§7Create a new home location', 'textures/ui/color_plus');
    form.button('§e§l🏠 TELEPORT TO HOME\n§7Visit one of your homes', 'textures/ui/arrow_right');
    form.button('§c§l🗑️ DELETE HOME\n§7Remove a home location', 'textures/ui/trash');
    form.button('§8§l❌ CLOSE\n§7Exit the menu', 'textures/ui/cancel');
    
    try {
        const response = await form.show(player);
        
        if (response.canceled) return;
        
        switch (response.selection) {
            case 0:
                showSetHomeMenu(player);
                break;
            case 1:
                showTeleportMenu(player);
                break;
            case 2:
                showDeleteMenu(player);
                break;
            case 3:
                return;
        }
    } catch (error) {
        player.sendMessage('§c§l❌ §7An error occurred while opening the menu.');
    }
}

// Set home menu
async function showSetHomeMenu(player) {
    const homes = homeManager.getPlayerHomes(player.id);
    const limit = homeManager.getPlayerHomeLimit(player);
    
    if (homes.length >= limit) {
        const form = new MessageFormData();
        form.title('§c§lHOME LIMIT REACHED');
        form.body(`§7You have reached your home limit of §c${limit}§7!\n\n§7You must delete a home before creating a new one.`);
        form.button1('§a§l← BACK TO MENU');
        form.button2('§c§l🗑️ DELETE HOME');
        
        const response = await form.show(player);
        if (response.selection === 0) {
            showMainMenu(player);
        } else if (response.selection === 1) {
            showDeleteMenu(player);
        }
        return;
    }
    
    const form = new ModalFormData();
    form.title('§a§lSET NEW HOME');
    form.textField('§e§lHome Name:\n§7Enter a name for your home', 'My Home');
    
    try {
        const response = await form.show(player);
        
        if (response.canceled) {
            showMainMenu(player);
            return;
        }
        
        const homeName = response.formValues[0];
        
        if (!homeName || homeName.trim() === '') {
            player.sendMessage('§c§l❌ §7Please enter a valid home name!');
            showSetHomeMenu(player);
            return;
        }
        
        const location = {
            x: Math.floor(player.location.x),
            y: Math.floor(player.location.y),
            z: Math.floor(player.location.z),
            dimension: player.dimension.id
        };
        
        const success = homeManager.addHome(player, homeName, location);
        
        if (success) {
            player.sendMessage(`§a§l✓ §7Home '§e${homeName}§7' has been set at §b${location.x}, ${location.y}, ${location.z}§7!`);
            player.playSound('note.pling');
        } else {
            player.sendMessage('§c§l❌ §7Failed to set home. You may have reached your limit.');
        }
        
        showMainMenu(player);
    } catch (error) {
        player.sendMessage('§c§l❌ §7An error occurred while setting the home.');
        showMainMenu(player);
    }
}

// Teleport menu
async function showTeleportMenu(player) {
    const homes = homeManager.getPlayerHomes(player.id);
    
    if (homes.length === 0) {
        const form = new MessageFormData();
        form.title('§e§l⚠️ NO HOMES SET');
        form.body('§7You haven\'t set any homes yet!\n\n§7Use the §a§lSet Home§7 option to create your first home.');
        form.button1('§a§l← BACK TO MENU');
        form.button2('§a§l➕ SET HOME NOW');
        
        const response = await form.show(player);
        if (response.selection === 0) {
            showMainMenu(player);
        } else if (response.selection === 1) {
            showSetHomeMenu(player);
        }
        return;
    }
    
    const form = new ActionFormData();
    form.title('§e§lTELEPORT TO HOME');
    form.body('§7Select a home to teleport to:');
    
    homes.forEach(home => {
        form.button(`§b§l${home.name}\n§7${home.x}, ${home.y}, ${home.z}`, 'textures/ui/arrow_right');
    });
    
    form.button('§8§l← BACK TO MENU', 'textures/ui/cancel');
    
    try {
        const response = await form.show(player);
        
        if (response.canceled) {
            showMainMenu(player);
            return;
        }
        
        if (response.selection === homes.length) {
            showMainMenu(player);
            return;
        }
        
        const selectedHome = homes[response.selection];
        
        // Teleport player
        player.teleport(
            { x: selectedHome.x + 0.5, y: selectedHome.y, z: selectedHome.z + 0.5 },
            { dimension: world.getDimension(selectedHome.dimension) }
        );
        
        player.sendMessage(`§a§l✓ §7Teleported to home '§e${selectedHome.name}§7'!`);
        player.playSound('mob.endermen.portal');
        
    } catch (error) {
        player.sendMessage('§c§l❌ §7An error occurred while teleporting.');
    }
}

// Delete menu
async function showDeleteMenu(player) {
    const homes = homeManager.getPlayerHomes(player.id);
    
    if (homes.length === 0) {
        const form = new MessageFormData();
        form.title('§e§l⚠️ NO HOMES TO DELETE');
        form.body('§7You don\'t have any homes to delete!');
        form.button1('§a§l← BACK TO MENU');
        form.button2('§a§l➕ SET HOME');
        
        const response = await form.show(player);
        if (response.selection === 0) {
            showMainMenu(player);
        } else if (response.selection === 1) {
            showSetHomeMenu(player);
        }
        return;
    }
    
    const form = new ActionFormData();
    form.title('§c§lDELETE HOME');
    form.body('§7Select a home to delete:\n\n§c§l⚠️ WARNING: This action cannot be undone!');
    
    homes.forEach(home => {
        form.button(`§c§l${home.name}\n§7${home.x}, ${home.y}, ${home.z}`, 'textures/ui/trash');
    });
    
    form.button('§8§l← BACK TO MENU', 'textures/ui/cancel');
    
    try {
        const response = await form.show(player);
        
        if (response.canceled) {
            showMainMenu(player);
            return;
        }
        
        if (response.selection === homes.length) {
            showMainMenu(player);
            return;
        }
        
        const selectedHome = homes[response.selection];
        
        // Confirmation dialog
        const confirmForm = new MessageFormData();
        confirmForm.title('§c§lCONFIRM DELETION');
        confirmForm.body(`§7Are you sure you want to delete home '§e${selectedHome.name}§7'?\n\n§c§lThis action cannot be undone!`);
        confirmForm.button1('§a§l← CANCEL');
        confirmForm.button2('§c§l🗑️ DELETE');
        
        const confirmResponse = await confirmForm.show(player);
        
        if (confirmResponse.selection === 1) {
            const success = homeManager.removeHome(player.id, selectedHome.name);
            
            if (success) {
                player.sendMessage(`§a§l✓ §7Home '§e${selectedHome.name}§7' has been deleted!`);
                player.playSound('note.bass');
            } else {
                player.sendMessage('§c§l❌ §7Failed to delete home.');
            }
        }
        
        showMainMenu(player);
        
    } catch (error) {
        player.sendMessage('§c§l❌ §7An error occurred while deleting the home.');
        showMainMenu(player);
    }
}

// List homes menu
async function showListHomesMenu(player) {
    const homes = homeManager.getPlayerHomes(player.id);
    const limit = homeManager.getPlayerHomeLimit(player.id);
    
    let homesList = '';
    if (homes.length === 0) {
        homesList = '§7No homes set yet!';
    } else {
        homesList = homes.map((home, index) => 
            `§b${index + 1}. §e§l${home.name}\n   §7Location: §f${home.x}, ${home.y}, ${home.z}\n   §7Dimension: §f${home.dimension}\n`
        ).join('\n');
    }
    
    const form = new MessageFormData();
    form.title('§d§l📋 YOUR HOMES');
    form.body(`§7Home Count: §f${homes.length}§7/§f${limit}\n\n${homesList}`);
    form.button1('§a§l← BACK TO MENU');
    form.button2('§e§l🏠 TELEPORT');
    
    try {
        const response = await form.show(player);
        
        if (response.selection === 0) {
            showMainMenu(player);
        } else if (response.selection === 1) {
            showTeleportMenu(player);
        }
    } catch (error) {
        showMainMenu(player);
    }
}

// Admin commands - Fixed to work with tag system
world.beforeEvents.chatSend.subscribe((event) => {
    const { sender: player, message } = event;
    
    // Check if player is trying to use tag command for setting home limits
    if (message.startsWith('/tag @s add homes') && player.hasTag('admin')) {
        event.cancel = true;
        
        const match = message.match(/\/tag @s add homes(\d+)/);
        if (match) {
            const newLimit = parseInt(match[1]);
            if (newLimit > 0) {
                // Remove all existing homes tags
                const tags = player.getTags();
                tags.forEach(tag => {
                    if (tag.startsWith('homes') && tag.length > 5) {
                        player.removeTag(tag);
                    }
                });
                
                // Add new homes tag
                player.addTag(`homes${newLimit}`);
                player.sendMessage(`§a§l✓ §7Your home limit has been set to §b${newLimit}§7!`);
            } else {
                player.sendMessage('§c§l❌ §7Home limit must be greater than 0!');
            }
        } else {
            player.sendMessage('§c§l❌ §7Usage: /tag @s add homes<number> (e.g., /tag @s add homes5)');
        }
        return;
    }
    
    if (message.startsWith('/sethome')) {
        event.cancel = true;
        
        const args = message.split(' ');
        
        if (args[1] === 'help') {
            if (player.hasTag('admin')) {
                player.sendMessage('§6§l=== SETHOME ADMIN COMMANDS ===');
                player.sendMessage('§e/tag @s add homes<number> §7- Set your home limit (e.g., /tag @s add homes5)');
                player.sendMessage('§e/sethome help §7- Show this help');
                player.sendMessage('§7Use the compass to access the GUI!');
            } else {
                player.sendMessage('§6§l=== SETHOME COMMANDS ===');
                player.sendMessage('§e/sethome help §7- Show this help');
                player.sendMessage('§7Use the compass to access the GUI!');
            }
        } else {
            player.sendMessage('§c§l❌ §7Unknown command. Use §e/sethome help §7for help.');
        }
    }
});

// Initialize system
system.run(() => {
    console.log('§a§l[Sethome] §7Addon loaded successfully!');
});